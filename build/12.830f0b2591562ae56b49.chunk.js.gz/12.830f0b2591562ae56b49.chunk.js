(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[12],{

/***/ "4d170daeaeaeaee6db69":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "e32e74997266e8a64b6c75e4891a2a60.svg";

/***/ }),

/***/ "661391b676f99216df8e":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "ad710724a81d667ac4059f76bca4c9a7.svg";

/***/ }),

/***/ "92751fa681f28a0ecebb":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "45a35546468334da2eb06e94e6c0cd15.svg";

/***/ }),

/***/ "df9066923737f7d6d23f":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return HomePage; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("8af190b70a6bc55c6f1b");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("fc43733ec9d3f066c334");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("8113359511cd270e25e9");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("a5212af3d6b7e4a810a0");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("0da2b258a142f2074b40");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("85b71a27cbcf93ff4854");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("ac9a73a0fc482b8c6e3b");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("738f8fe4ade3e5cc0c02");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("93f2d5343bd6146d76c5");
/* harmony import */ var components_MainLayout__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("7cb1268c064758069424");
/* harmony import */ var _images_logo_svg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("776f7b15d44f70e7504d");
/* harmony import */ var _images_logo_svg__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_images_logo_svg__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _common_AppStyle__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("23fe7c4c131f6fb8bfb8");
/* harmony import */ var react_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("103be25b8913a0141218");
/* harmony import */ var _images_home_item1_svg__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__("bb973cf060c99f47034c");
/* harmony import */ var _images_home_item1_svg__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_images_home_item1_svg__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _images_home_item2_svg__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__("f3f224af3d9e7854b6d9");
/* harmony import */ var _images_home_item2_svg__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_images_home_item2_svg__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _images_home_item3_svg__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__("92751fa681f28a0ecebb");
/* harmony import */ var _images_home_item3_svg__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_images_home_item3_svg__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _images_home_item4_svg__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__("f7d71a8bfe709f2f324b");
/* harmony import */ var _images_home_item4_svg__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_images_home_item4_svg__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _images_home_item5_svg__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__("ba1b7c72facb90889fbe");
/* harmony import */ var _images_home_item5_svg__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_images_home_item5_svg__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _images_home_item6_svg__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__("661391b676f99216df8e");
/* harmony import */ var _images_home_item6_svg__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_images_home_item6_svg__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _images_home_item7_svg__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__("4d170daeaeaeaee6db69");
/* harmony import */ var _images_home_item7_svg__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_images_home_item7_svg__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _material_ui_icons_Star__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__("ee64036e804fdbc28f92");
/* harmony import */ var _material_ui_icons_Star__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Star__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__("0a81c721557e72a0975d");
/* harmony import */ var _material_ui_core_colors__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__("56b94766eb558a26012b");

















var useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(function (theme) {
  return {
    cardHeader: {
      marginLeft: 24,
      marginRight: 36,
      marginTop: 60
    },
    cardItem: {
      marginTop: 12,
      marginLeft: 24,
      marginRight: 24,
      marginBottom: 12,
      cursor: 'pointer'
    },
    imgLogo: {
      display: 'flex',
      paddingTop: 60
    },
    txtTitle: {
      fontSize: 16
    },
    txtTitleSub: {
      color: '#007DFF'
    },
    media: {
      minHeight: 120
    }
  };
});
var MENU_LOGINED = [{
  title: '学習実績',
  img: _images_home_item1_svg__WEBPACK_IMPORTED_MODULE_13___default.a,
  subtitle: '受講履歴を確認する',
  linkTo: '/achivements'
}, {
  title: 'E-learning',
  img: _images_home_item2_svg__WEBPACK_IMPORTED_MODULE_14___default.a,
  subtitle: 'E-learningに挑戦する',
  linkTo: '/e-learning/elearning-check'
}, {
  title: '模擬患者',
  img: _images_home_item3_svg__WEBPACK_IMPORTED_MODULE_15___default.a,
  subtitle: 'VirtualPatientsに挑戦する',
  linkTo: '/vps/top'
}, {
  title: '昇級試験',
  img: _images_home_item4_svg__WEBPACK_IMPORTED_MODULE_16___default.a,
  subtitle: '昇級試験に挑戦する'
}, {
  title: '実力試験',
  img: _images_home_item5_svg__WEBPACK_IMPORTED_MODULE_17___default.a,
  subtitle: '実力試験に挑戦する',
  subtitle2: '※条件を満たしていないため、実力試験を開始できません',
  linkTo: '/e-learning/check-ability1'
}, {
  title: '有料セミナー',
  img: _images_home_item6_svg__WEBPACK_IMPORTED_MODULE_18___default.a,
  subtitle: '有料セミナーを確認する',
  linkTo: '/seminar/paid-seminars'
}, {
  title: 'お知らせ',
  img: _images_home_item7_svg__WEBPACK_IMPORTED_MODULE_19___default.a,
  subtitle: 'お知らせを確認する',
  linkTo: '/notice-list'
}];
var MENU_NOT_LOGINED = [{
  title: '学習実績',
  img: _images_home_item1_svg__WEBPACK_IMPORTED_MODULE_13___default.a,
  subtitle: '受講履歴を確認する',
  linkTo: '/achivements'
}, {
  title: 'E-learning',
  img: _images_home_item2_svg__WEBPACK_IMPORTED_MODULE_14___default.a,
  subtitle: 'E-learningに挑戦する',
  actionTitle: '会員登録する',
  actionLink: '/payment-info',
  linkTo: '/e-learning/elearning-check'
}, {
  title: '模擬患者',
  img: _images_home_item3_svg__WEBPACK_IMPORTED_MODULE_15___default.a,
  subtitle: 'VirtualPatientsに挑戦する',
  actionTitle: '会員登録する',
  actionLink: '/payment-info',
  linkTo: '/vps/top'
}, {
  title: '昇級試験',
  img: _images_home_item4_svg__WEBPACK_IMPORTED_MODULE_16___default.a,
  subtitle: '昇級試験に挑戦する'
}, {
  title: '実力試験',
  img: _images_home_item5_svg__WEBPACK_IMPORTED_MODULE_17___default.a,
  subtitle: '実力試験に挑戦する',
  subtitle2: '※条件を満たしていないため、実力試験を開始できません',
  linkTo: '/e-learning/check-ability1'
}, {
  title: '有料セミナー',
  img: _images_home_item6_svg__WEBPACK_IMPORTED_MODULE_18___default.a,
  subtitle: '有料セミナーを確認する',
  linkTo: '/seminar/paid-seminars'
}, {
  title: 'お知らせ',
  img: _images_home_item7_svg__WEBPACK_IMPORTED_MODULE_19___default.a,
  subtitle: 'お知らせを確認する',
  linkTo: '/notice-list'
}];
function HomePage() {
  var classes = useStyles();
  var classesApp = Object(_common_AppStyle__WEBPACK_IMPORTED_MODULE_11__[/* default */ "a"])();
  var history = Object(react_router__WEBPACK_IMPORTED_MODULE_12__[/* useHistory */ "f"])();
  var isLogined = Object(react_redux__WEBPACK_IMPORTED_MODULE_21__[/* useSelector */ "e"])(function (state) {
    return state.config.is_logined;
  });
  return react__WEBPACK_IMPORTED_MODULE_0__["createElement"](components_MainLayout__WEBPACK_IMPORTED_MODULE_9__[/* default */ "a"], null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"], {
    className: classes.imgLogo
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("img", {
    src: _images_logo_svg__WEBPACK_IMPORTED_MODULE_10___default.a,
    className: classesApp.mrAuto
  })), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"], {
    className: classes.cardHeader,
    variant: "outlined"
  }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"], null, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"], {
    color: "textSecondary",
    gutterBottom: true
  }, "\u8A8D\u5B9A\u533B\u7D1A"), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"], {
    color: "textPrimary",
    gutterBottom: false,
    variant: "h5"
  }, "Get\u3057\u305F\u661F\uFF1A ", react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_icons_Star__WEBPACK_IMPORTED_MODULE_20___default.a, {
    fontSize: "large",
    style: {
      color: _material_ui_core_colors__WEBPACK_IMPORTED_MODULE_22__[/* default */ "a"][500],
      fontSize: '3.5rem'
    }
  }), "40\u500B"))), (isLogined ? MENU_LOGINED : MENU_NOT_LOGINED).map(function (card, index) {
    return react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"], {
      key: "card--".concat(index),
      className: classes.cardItem,
      onClick: function onClick() {
        return !!card.linkTo && history.push(card.linkTo);
      }
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"], {
      title: card.title
    }), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"], {
      className: classes.media,
      image: card.img,
      title: "Contemplative Reptile"
    }), react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core__WEBPACK_IMPORTED_MODULE_8__[/* default */ "a"], {
      style: {
        paddingTop: 8,
        paddingBottom: 16,
        display: 'block'
      }
    }, react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"], {
      className: classes.txtTitleSub
    }, card.subtitle), !!card.subtitle2 && react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"], {
      onClick: function onClick() {
        return console.log("wegweg w");
      },
      className: classes.txtTitleSub,
      style: {
        color: '#FF0000'
      }
    }, card.subtitle2), !!card.actionTitle && react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_material_ui_core__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"], {
      onClick: function onClick(e) {
        e.preventDefault();
        e.stopPropagation();
        history.push(card.actionLink);
      },
      className: classes.txtTitleSub,
      style: {
        marginTop: 24
      }
    }, card.actionTitle)));
  }));
}

/***/ })

}]);